# Copyright (C) 2021 By VeezMusicProject

class DurationLimitError(Exception):
    pass


class FFmpegReturnCodeError(Exception):
    pass
